var express = require("express");
var router = express.Router();
var fs = require('fs');
var Caman = require('caman').Caman;
var Jimp = require("jimp");
var path = require("path");
var cv = require("opencv");
var multer  =   require('multer');
var ffmpeg = require('fluent-ffmpeg');
var fse = require('fs-extra');

//generate unique token for the session
var session_token = getRandomInt(1, 10000000).toString();

//declared to pass data to analysis
var image_width;
var image_height;
var worm_array;
var velocity_array;
var im1w, im1h, im2w, im2h;
var velocities = [];

var current_path = __dirname.toString();

var storage =   multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, current_path);
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + '-' + session_token + ".png");
  }
});

var storage_vid =   multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, current_path + "/../public/video");
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + '-' + session_token + ".mp4");
  }
});

var upload = multer({ storage : storage}).single('photo');
var upload_vid = multer({ storage : storage_vid}).single('video');


router.get("/", function(req,res) {
    res.render("index");
    //count objects and delete if folder is too big (over 100 items)
    /*
    var item_count = 0;
    fse.walk('./public/uploads')
    .on('data', function (item) {
        item_count = item_count + 1;
    })
    .on('end', function () {
        if (item_count > 100) {
        fse.emptyDir('./public/uploads', function (err) {
            if (err) {
                console.log('File not found!');
            } 
        });
        }
    });
    */

});

router.get("/about", function(req,res) {
    res.render("about");
});

router.get("/analyze", function(req,res) {
    res.render("analyze");
});

router.get("/measure", function(req,res) {
    res.render("draw");
});


router.post("/analyze", function(req,res) {
    upload(req,res,function(err) {
        if(err) {
            res.redirect("/analyze");
        }

        var area_percent = parseFloat(req.body.area_percent);

        initial_process(session_token);
        while(!fileExists( current_path +  "/output-" + session_token + ".png")) {require('deasync').sleep(1000);}
        processWorms(session_token);
        while(!fileExists( current_path +  "/processed-" + session_token + ".png")) {require('deasync').sleep(1000);}
        find_contours(session_token, area_percent);
        
        res.redirect("/analyze/" + session_token);
    });
});

router.get("/analyze/:token", function(req,res) {
    var token = req.params.token;
    if (fileExists(current_path +  "/photo-" + token + ".png")){fs.unlinkSync( current_path +  "/photo-" + token + ".png");}
    if (fileExists(current_path +  "/output-" + token + ".png")){fs.unlinkSync( current_path +  "/output-" + token + ".png");}
    if (fileExists( current_path +  "/processed-" + token + ".png")){fs.unlinkSync( current_path +  "/processed-" + token + ".png");}

    var image_link = ("/images" +  "/worms-" + token + ".png");

    res.render("analyze_image", {image_link: image_link, image_width: image_width, image_height: image_height, worm_array: worm_array});
});


router.get("/video", function(req,res) {
    res.render("video_analyze");
});

router.post("/video", function(req,res) {
    upload_vid(req,res,function(err) {
        if(err) {
            res.redirect("/video_analyze");
        }
        res.redirect("/video_analyze/" + session_token);
    });
});

router.get("/video_analyze/:token", function(req,res) {
    var token = req.params.token;
    var video_path = ("/video" + "/video-" + token + ".mp4");
    res.render("analyze_single_video", {video_path: video_path, token: token});
});

router.post("/video_analyze/:token", function(req,res) {
    var token = req.params.token;
    var time_point = req.body.time;
    var area_percent_image = parseFloat(req.body.areapercent);
    var new_session_token = getRandomInt(1,1000000000).toString();
    var proc = new ffmpeg(current_path + "/../public/video/video-" + token + ".mp4")
    .takeScreenshots({
        count: 1,
        filename: "photo-" + new_session_token,
        timemarks: [time_point ] // number of seconds
        }, current_path, function(err) {
  });
        while(!fileExists(current_path +  "/photo-" + new_session_token + ".png")) {require('deasync').sleep(1000);}
        initial_process(new_session_token);
        while(!fileExists( current_path +  "/output-" + new_session_token + ".png")) {require('deasync').sleep(1000);}
        processWorms(new_session_token);
        while(!fileExists( current_path +  "/processed-" + new_session_token + ".png")) {require('deasync').sleep(1000);}
        find_contours(new_session_token,area_percent_image);
        
        res.redirect("/analyze/" + new_session_token);
});

router.post("/video_velocity/:token", function(req,res) {
    var token = req.params.token;
    var start_time = req.body.start_time;
    var end_time = req.body.end_time;
    var time_between = end_time - start_time;
    var area_percent_image = parseFloat(req.body.areapercent_velocity);
    var new_session_token = getRandomInt(1,1000000000).toString();
    var second_new_sessions_token = getRandomInt(1,1000000000).toString();
    var proc = new ffmpeg(current_path + "/../public/video/video-" + token + ".mp4")
    .takeScreenshots({
        count: 1,
        filename: "photo-" + new_session_token,
        timemarks: [start_time ] // number of seconds
        }, current_path, function(err) {
  });
  var proc_two = new ffmpeg(current_path + "/../public/video/video-" + token + ".mp4")
    .takeScreenshots({
        count: 1,
        filename: "photo-" + second_new_sessions_token,
        timemarks: [end_time ] // number of seconds
        }, current_path, function(err) {
  });

  //two images now created
        while(!fileExists(current_path +  "/photo-" + new_session_token + ".png") && !fileExists(current_path +  "/photo-" + second_new_sessions_token + ".png")) {require('deasync').sleep(1000);}
        initial_process(new_session_token);
        initial_process(second_new_sessions_token);
        while(!fileExists(current_path +  "/output-" + new_session_token + ".png") && !fileExists(current_path +  "/output-" + second_new_sessions_token + ".png")) {require('deasync').sleep(1000);}
        processWorms(new_session_token);
        processWorms(second_new_sessions_token);
        while(!fileExists(current_path +  "/processed-" + new_session_token + ".png") && !fileExists(current_path +  "/processed-" + second_new_sessions_token + ".png")) {require('deasync').sleep(1000);}
        //two files are now created.
        
        get_velocity(new_session_token, second_new_sessions_token, time_between, area_percent_image);
        var image_one_link = ("/images" +  "/worms-" + new_session_token + ".png");
        var image_two_link = ("/images" +  "/worms-" + second_new_sessions_token + ".png");
        
        res.render("velocities", {image_one_link: image_one_link, image_two_link: image_two_link, image_one_width: im1w, image_one_height: im1h, image_two_width: im2w, image_two_height: im2h, velocities: velocities});
        while(!fileExists( current_path +  "/worms-" + new_session_token + ".png") && !fileExists( current_path +  "/worms-" + second_new_sessions_token + ".png")) {require('deasync').sleep(1000);}
        //delete old files to keep room
        fs.unlinkSync( current_path +  "/photo-" + new_session_token + ".png");
        fs.unlinkSync( current_path +  "/photo-" + second_new_sessions_token + ".png");
        fs.unlinkSync( current_path +  "/output-" + new_session_token + ".png");
        fs.unlinkSync( current_path +  "/output-" + second_new_sessions_token + ".png");
        fs.unlinkSync( current_path +  "/processed-" + new_session_token + ".png");
        fs.unlinkSync( current_path +  "/processed-" + second_new_sessions_token + ".png");

});

router.get("/video_velocity/:token", function(req,res) {
    res.redirect("/video");
});













function initial_process(session_token) {
    
    Caman( current_path +  "/photo-" + session_token + ".png", function () {
                this.contrast(65);
                this.hue(100);
                this.vibrance(100);
                this.greyscale();
                this.render(function () {
                    this.save( current_path +  "/output-" + session_token + ".png");
                });
            });
    
}

function processWorms(session_token) {
    
    Jimp.read( current_path +  "/output-" + session_token + ".png").then(function (pic) {
        
        
    pic.scan(0, 0, pic.bitmap.width, pic.bitmap.height, function (x, y, idx) {
             var red   = this.bitmap.data[ idx + 0 ];
             var green = this.bitmap.data[ idx + 1 ];
             var blue  = this.bitmap.data[ idx + 2 ];

            if (red > 210 && blue > 210 && green > 210) {
                        this.bitmap.data[idx] = 255;
                        this.bitmap.data[idx + 1] = 255;
                        this.bitmap.data[idx + 2] = 255;
            }
        });

        for (var i = 0; i<20; i++) {
        //goes through each pixel
        pic.scan(0, 0, pic.bitmap.width, pic.bitmap.height, function (x, y, idx) {
             var red   = this.bitmap.data[ idx + 0 ];
             var green = this.bitmap.data[ idx + 1 ];
             var blue  = this.bitmap.data[ idx + 2 ];
             
             if (red != 255 && blue != 255 && green != 255) 
             {
                 var bottom_is_white = false;
                 var right_is_white = false;
                 if (y+1 < pic.bitmap.height) {
                     var hex = pic.getPixelColor(x, y+1); 
                     var r, g, b, a = Jimp.intToRGBA(hex);
                     var bottom_is_white = (r == 255 && b == 255 && g == 255);
                 }
             
                 if (x+1 < pic.bitmap.width) {
                    var hex = pic.getPixelColor(x+1, y); 
                    var r, g, b, a = Jimp.intToRGBA(hex);
                    var right_is_white = (r == 255 && b == 255 && g == 255);
                 }

                 


                 if (bottom_is_white || right_is_white) {
                     this.bitmap.data[idx] = 255;
                     this.bitmap.data[idx + 1] = 255;
                     this.bitmap.data[idx + 2] = 255;
                 }
             }

    });
        }
        
         pic.write( current_path +  "/processed-" + session_token + ".png"); // save 
}).catch(function (err) {
    console.error(err);
});

}

function find_contours(session_token, area_percent) {
    

  cv.readImage( current_path +  "/processed-" + session_token + ".png", function(err, im){
      
    if (err) throw err;
    worm_array = [];
    var width = im.width();
    var height = im.height();
    image_width = im.width();
    image_height = im.height();
    var total_area = width*height;
    var maxArea;
    if (!area_percent) {maxArea = 2500;}
    else {
     maxArea = parseFloat(total_area) * area_percent;
    }
   
    var GREEN = [0, 255, 0]; // B, G, R
    var WHITE = [255, 255, 255]; // B, G, R
    var RED   = [0, 0, 255]; // B, G, R

    var worm_contours = [];

    

    var big = new cv.Matrix(height, width);
    var all = new cv.Matrix(height, width);

    im.convertGrayscale();
    var im_canny = im.copy();
    im_canny.canny(0, 100);
    im_canny.dilate(2);

    var contours = im_canny.findContours();

    for(i = 0; i < contours.size(); i++) {
    if(contours.area(i) > maxArea) {


      worm_contours.push(i);
      var moments = contours.moments(i);
      var cgx = Math.round(moments.m10 / moments.m00);
      var cgy = Math.round(moments.m01 / moments.m00);
      big.drawContour(contours, i, GREEN);


      var array_of_points = contours.boundingRect(i);
      var point1 = [array_of_points["x"], array_of_points["y"]];
      var point2 = [array_of_points["width"], array_of_points["height"]]
      big.rectangle(point1, point2, WHITE);
      

      
      //arclength is the perimeter
      big.putText(worm_contours.length.toString(), cgx, cgy, "HERSEY_COMPLEX_SMALL", RED, 1, 1);

      var array_len = Number((contours.arcLength(i)/2.0).toFixed(1));
      var array_area = Number((contours.area(i)).toFixed(1));
      var array_width = array_of_points["width"];
      var array_height = array_of_points["height"];


     worm_array.push({len: array_len, area: array_area, bounding_width: array_width, bounding_height: array_height});   
     array_of_points = [];
    }
  }



  big.save(current_path +  "/../public/images/worms-" + session_token + ".png");
});
}



function get_velocity(first_token, second_token, time, area_percent) {

    var image_one_width;
    var image_one_height;
    var image_two_width;
    var image_two_height;
    var image_one_positions = [];
    var image_two_positions = [];
    var velocity_array = [];

    cv.readImage(current_path +  "/processed-" + first_token + ".png", function(err, im){
    if (err) throw err;
    var width = im.width();
    var height = im.height();
    image_one_width = width;
    image_one_height = height;
    var total_area = width*height;
    var maxArea;
    if (!area_percent) {maxArea = 2500;}
    else {
     maxArea = parseFloat(total_area) * area_percent;
    }
    var GREEN = [0, 255, 0]; // B, G, R
    var WHITE = [255, 255, 255]; // B, G, R
    var RED   = [0, 0, 255]; // B, G, R

    var worm_contours = [];
    var big = new cv.Matrix(height, width);

    im.convertGrayscale();
    var im_canny = im.copy();
    im_canny.canny(0, 100);
    im_canny.dilate(2);

    var contours = im_canny.findContours();

    for(i = 0; i < contours.size(); i++) {
    if(contours.area(i) > maxArea) {
      worm_contours.push(i);
      var moments = contours.moments(i);
      var cgx = Math.round(moments.m10 / moments.m00);
      var cgy = Math.round(moments.m01 / moments.m00);
      big.drawContour(contours, i, GREEN);
      var array_of_points = contours.boundingRect(i);
      var point1 = [array_of_points["x"], array_of_points["y"]];
      var point2 = [array_of_points["width"], array_of_points["height"]]
      big.rectangle(point1, point2, WHITE);
      big.putText(worm_contours.length.toString(), cgx, cgy, "HERSEY_COMPLEX_SMALL", RED, 1, 1);

     image_one_positions.push({x: cgx, y: cgy});  
     array_of_points = [];
    }
  }
  big.save(current_path +  "/../public/images/worms-" + first_token + ".png");
});

    cv.readImage(current_path +  "/processed-" + second_token + ".png", function(err, im){
    if (err) throw err;
    var width = im.width();
    var height = im.height();
    image_two_width = width;
    image_two_height = height;
    var total_area = width*height;
    var maxArea;
    if (!area_percent) {maxArea = 2500;}
    else {
     maxArea = parseFloat(total_area) * area_percent;
    }
    var GREEN = [0, 255, 0]; // B, G, R
    var WHITE = [255, 255, 255]; // B, G, R
    var RED   = [0, 0, 255]; // B, G, R

    var worm_contours = [];
    var big = new cv.Matrix(height, width);

    im.convertGrayscale();
    var im_canny = im.copy();
    im_canny.canny(0, 100);
    im_canny.dilate(2);

    var contours = im_canny.findContours();

    for(i = 0; i < contours.size(); i++) {
    if(contours.area(i) > maxArea) {
      worm_contours.push(i);
      var moments = contours.moments(i);
      var cgx = Math.round(moments.m10 / moments.m00);
      var cgy = Math.round(moments.m01 / moments.m00);
      big.drawContour(contours, i, GREEN);
      var array_of_points = contours.boundingRect(i);
      var point1 = [array_of_points["x"], array_of_points["y"]];
      var point2 = [array_of_points["width"], array_of_points["height"]]
      big.rectangle(point1, point2, WHITE);
      big.putText(worm_contours.length.toString(), cgx, cgy, "HERSEY_COMPLEX_SMALL", RED, 1, 1);

     image_two_positions.push({x: cgx, y: cgy});  
     array_of_points = [];
    }
  }
  big.save(current_path +  "/../public/images/worms-" + second_token + ".png");
});
//now have two position arrays of points in image_one_positions and image_two_positions
 var length_one = image_one_positions.length;
 var length_two = image_two_positions.length;
 if (length_one > length_two) {
     image_one_positions = image_one_positions.slice(0,length_two-1);
 }
 if (length_one < length_two) {
     image_two_positions = image_two_positions.slice(0,length_one-1);
 }
 //now equal length
 for (var i = 0; i < image_one_positions.length; i++) {
     var x1 = image_one_positions[i].x;
     var y1 = image_one_positions[i].y;
     var x2 = image_two_positions[i].x;
     var y2 = image_two_positions[i].y;

     var displacement = Math.sqrt( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) );
     var velocity = displacement / time;
     
     velocity_array.push(velocity);
 }

 im1w = image_one_width;
 im1h = image_one_height;
 im2w = image_two_width;
 im2h = image_two_height;
 velocities = velocity_array;


}



function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function fileExists(filePath)
{
    try
    {
        return fs.statSync(filePath).isFile();
    }
    catch (err)
    {
        return false;
    }
}




module.exports = router;
